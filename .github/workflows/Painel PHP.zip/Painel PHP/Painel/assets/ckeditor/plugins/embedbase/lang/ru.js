/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'ru', {
	pathName: 'Медиа объект',
	title: 'Медиаконтент',
	button: 'Вставить Медиаконтент',
	unsupportedUrlGiven: 'Данный URL не поддерживается.',
	unsupportedUrl: 'URL {url} не поддерживается Media Embed.',
	fetchingFailedGiven: 'Не удалось подгрузить содержимое для заданного URL',
	fetchingFailed: 'Не удалось подгрузить содержимое для {url}',
	fetchingOne: 'Подгружаем oEmbed ответ...',
	fetchingMany: 'Подгружаем oEmbed ответы, {current} из {max} подгружено...'
} );
