-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 30, 2019 at 03:33 PM
-- Server version: 10.2.25-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `darkcine_app2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `email`, `image`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com', 'profile.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cid` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cid`, `category_name`, `category_image`, `status`) VALUES
(1, 'Sports', '18595_4665.jpg', 1),
(2, 'Fashion', '94282_fashionchannels.png', 1),
(3, 'Entertainment', '44775_shutterstock_624398861.jpg', 1),
(4, 'News', '66925_PJ_2016.07.07_Modern-News-Consumer_0-01.png', 1),
(5, 'Kids', '88870_children-happy.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_channels`
--

CREATE TABLE `tbl_channels` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `channel_type` varchar(255) NOT NULL,
  `channel_title` varchar(100) NOT NULL,
  `channel_url` text NOT NULL,
  `channel_type_ios` varchar(255) NOT NULL,
  `channel_url_ios` text NOT NULL,
  `channel_poster` text NOT NULL,
  `channel_thumbnail` varchar(255) NOT NULL,
  `channel_desc` text NOT NULL,
  `featured_channel` int(1) NOT NULL DEFAULT 0,
  `slider_channel` int(1) NOT NULL DEFAULT 0,
  `total_views` int(11) NOT NULL DEFAULT 0,
  `total_rate` int(11) NOT NULL DEFAULT 0,
  `rate_avg` decimal(11,2) NOT NULL DEFAULT 0.00,
  `user_agent` varchar(60) NOT NULL,
  `user_agent_type` varchar(100) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_channels`
--

INSERT INTO `tbl_channels` (`id`, `cat_id`, `channel_type`, `channel_title`, `channel_url`, `channel_type_ios`, `channel_url_ios`, `channel_poster`, `channel_thumbnail`, `channel_desc`, `featured_channel`, `slider_channel`, `total_views`, `total_rate`, `rate_avg`, `user_agent`, `user_agent_type`, `status`) VALUES
(8, 3, 'youtube', 'MTV', 'https://www.youtube.com/watch?v=j6muwUGdvXw', 'youtube', 'https://www.youtube.com/watch?v=agFMqNB9BYM', '', '88773_mtv.png', '<p>MTV gives you the hottest buzz from the entertainment world that will keep you hooked! Be the first to catch the latest MTV shows, music, artists and more!</p>\r\n', 1, 0, 1381, 9, '4.00', '', '', 1),
(12, 3, 'youtube', 'record ao vivo', 'https://www.youtube.com/watch?v=kodw6ojbnoA', 'youtube', 'https://www.youtube.com/watch?v=ohKmfO2spms&list=PLQTSj-_9v-TTdgheDMpJL326oToltMPGu', '29141_unnamed.jpg', '69512_hqdefault_live.jpg', '<p>&nbsp;</p>\r\n\r\n<p>record ao vivo</p>\r\n', 1, 0, 793, 4, '5.00', '', '', 1),
(14, 1, 'live_url', 'Star Sports', 'http://qthttp.apple.com.edgesuite.net/1010qwoeiuryfg/sl.m3u8', 'youtube', 'https://www.youtube.com/watch?v=f6vRQ7rMWi4', '', '17953_star-sports-1.jpg', '<p>Watch Star Sports Live Streaming.</p>\r\n', 1, 0, 1289, 6, '4.00', '', '', 1),
(18, 5, 'youtube', 'WB Kids', 'https://www.youtube.com/watch?v=ESoXIeTLqxQ', 'youtube', 'https://www.youtube.com/watch?v=ESoXIeTLqxQ', '', '63074_WB_Kids.jpg', '<p>WBKids is the home of all of your favorite clips featuring characters from the Looney Tunes, Scooby-Doo, Tom and Jerry and More!</p>\r\n', 0, 0, 715, 4, '4.00', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_text` text NOT NULL,
  `type` varchar(60) NOT NULL,
  `comment_on` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_episode`
--

CREATE TABLE `tbl_episode` (
  `id` int(10) NOT NULL,
  `series_id` int(5) NOT NULL,
  `season_id` int(11) NOT NULL,
  `episode_title` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `episode_type` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `episode_url` text COLLATE utf8_unicode_ci NOT NULL,
  `video_id` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `episode_poster` text COLLATE utf8_unicode_ci NOT NULL,
  `total_views` int(10) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_episode`
--

INSERT INTO `tbl_episode` (`id`, `series_id`, `season_id`, `episode_title`, `episode_type`, `episode_url`, `video_id`, `episode_poster`, `total_views`, `status`) VALUES
(1, 1, 1, 'Winter is coming', 'server_url', 'https://www.googleapis.com/drive/v3/files/1noO3S9lu4y3N6mzHcbyB6jha1eyLJzsw?alt=media&key=AIzaSyCJzsscbrKdDkGChq8fh_cXAD-XQu36dRQ', '', '20190_13931_got1.jpg', 0, 1),
(2, 1, 1, 'The Kingsroad', 'server_url', 'https://www.googleapis.com/drive/v3/files/1J5zb3hhcgGMU-YbZXjpEYg0glybnxiWj?alt=media&key=AIzaSyCJzsscbrKdDkGChq8fh_cXAD-XQu36dRQ', '', '01072019125313_18522.jpg', 0, 1),
(3, 1, 1, 'Lord Snow', 'embedded_url', 'https://www.dailymotion.com/embed/video/x7btkcj', '', '01072019125504_24026.jpg', 0, 1),
(4, 1, 1, 'Cripples, Bastards, and Broken Things', 'youtube_url', '', '', '01072019125511_44315.jpg', 0, 1),
(5, 1, 1, 'The Wolf and the Lion', 'youtube_url', '', '', '01072019125041_53517.jpg', 0, 1),
(6, 1, 2, 'The North Remembers', 'youtube_url', 'https://www.youtube.com/watch?v=xmpdHrVfaTk', 'xmpdHrVfaTk', '12072019071340_75185.jpg', 0, 1),
(7, 1, 2, 'The Night Lands', 'youtube_url', 'https://www.youtube.com/watch?v=_KdSHWETfGM', '_KdSHWETfGM', '12072019071518_29315.jpg', 0, 1),
(8, 3, 4, '1x01', 'server_url', 'https://video.wixstatic.com/video/7cd0af_d4a0516198eb4185ad807c5d63f4e18b/480p/mp4/file.mp4', '', '30082019031008_1282.jpg', 0, 1),
(9, 3, 4, '1x02', 'server_url', 'https://video.wixstatic.com/video/7cd0af_c816b08190fa41e896b95073b2bd3f97/480p/mp4/file.mp4', '', '30082019031043_11497.jpg', 0, 1),
(10, 3, 4, '1x03', 'server_url', 'https://video.wixstatic.com/video/7cd0af_3fff521594424be1be8f69ae34e2df7a/480p/mp4/file.mp4', '', '30082019031236_27225.jpg', 0, 1),
(11, 4, 5, '1x01', 'server_url', 'https://1.bp.blogspot.com/-vPKdhBimxKM/XEXLV1owTAI/AAAAAAAAWXg/wMRjw5JLgcAP_lzSOddx7NhR9KDMQCUswCKgBGAs/m22/1x01.mp4', '', '30082019032026_9886.jpg', 0, 1),
(12, 4, 5, '1x02', 'server_url', 'https://2.bp.blogspot.com/-qGfxN_1QMwM/XEXLV39EJhI/AAAAAAAAWXg/yRDhhm-CnI8rGbR2FarmT8mlBXkg2IKGwCKgBGAs/m22/1x02.mp4', '', '30082019032002_90288.jpg', 0, 1),
(13, 4, 7, '3x01', 'server_url', 'https://video.wixstatic.com/video/77897b_10da4ff48d8e4aaaad80bf76fdccec2d/480p/mp4/file.mp4', '', '30082019032112_7455.jpg', 0, 1),
(14, 4, 7, '3x02', 'server_url', 'https://video.wixstatic.com/video/77897b_4abe138f09db4172b0878c1167a232e8/480p/mp4/file.mp4', '', '30082019032146_41589.jpg', 0, 1),
(15, 5, 8, 'Abertura', 'youtube_url', 'https://www.youtube.com/watch?v=t1dSr4o1mok&t=2s', 't1dSr4o1mok', '30082019032656_70487.jpg', 0, 1),
(16, 5, 8, 'abertura 2', 'youtube_url', 'https://www.youtube.com/watch?v=4zbW7e4mjSQ', '4zbW7e4mjSQ', '30082019032749_60037.jpg', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_genres`
--

CREATE TABLE `tbl_genres` (
  `gid` int(11) NOT NULL,
  `genre_name` varchar(255) NOT NULL,
  `genre_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_genres`
--

INSERT INTO `tbl_genres` (`gid`, `genre_name`, `genre_image`) VALUES
(1, 'Terror', '88406_Horror.jpg'),
(3, 'Ação', '33053_Action.jpg'),
(4, 'Suspense', '54577_Thrille.jpg'),
(5, 'Drama', '92886_Drama_2_23.jpg'),
(6, 'Romance', '35754_LoveMovie.jpg'),
(7, 'Comédia', '95352_Comedy.jpg'),
(8, 'Marvel', '76602_marvel-logo-wallpaper.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_home`
--

CREATE TABLE `tbl_home` (
  `id` int(11) NOT NULL,
  `home_title` varchar(255) NOT NULL,
  `home_banner` varchar(255) NOT NULL,
  `home_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_home`
--

INSERT INTO `tbl_home` (`id`, `home_title`, `home_banner`, `home_url`) VALUES
(1, 'Star Sports', '27783_Star_Sports.png', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native'),
(3, 'ABP News', '88806_abp_english.jpg', 'http://bglive-a.bitgravity.com/ndtv/prolo/live/native');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_language`
--

CREATE TABLE `tbl_language` (
  `id` int(11) NOT NULL,
  `language_name` varchar(60) NOT NULL,
  `language_background` varchar(30) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_language`
--

INSERT INTO `tbl_language` (`id`, `language_name`, `language_background`, `status`) VALUES
(2, '2016', 'E9900B', 1),
(5, '2018', '034EE9', 1),
(8, '2019', 'E91E63', 1),
(9, '2017', '86E963', 1),
(10, 'Português', 'C951E9', 1),
(11, 'Legendado', 'C0E92E', 1),
(12, 'CAM', '44091D', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_movies`
--

CREATE TABLE `tbl_movies` (
  `id` int(11) NOT NULL,
  `language_id` int(5) NOT NULL,
  `genre_id` varchar(50) NOT NULL,
  `movie_type` varchar(60) NOT NULL,
  `movie_title` varchar(255) NOT NULL,
  `movie_cover` text NOT NULL,
  `movie_poster` text NOT NULL,
  `movie_url` text NOT NULL,
  `video_id` varchar(150) NOT NULL,
  `movie_desc` longtext NOT NULL,
  `total_views` int(11) NOT NULL DEFAULT 0,
  `total_rate` varchar(30) NOT NULL DEFAULT '0',
  `rate_avg` varchar(30) NOT NULL DEFAULT '0',
  `is_featured` int(1) NOT NULL DEFAULT 0,
  `is_slider` int(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_movies`
--

INSERT INTO `tbl_movies` (`id`, `language_id`, `genre_id`, `movie_type`, `movie_title`, `movie_cover`, `movie_poster`, `movie_url`, `video_id`, `movie_desc`, `total_views`, `total_rate`, `rate_avg`, `is_featured`, `is_slider`, `status`) VALUES
(24, 8, '3,7,8', 'server_url', 'Vingadores: Ultimato (2019)', '79886_9wXPKruA6bWYk2co5ix6fH59Qr8.jpg', '23166_q6725aR8Zs4IwGMXzZT8aC8lh41 (1).jpg', 'http://mrq1.azureedge.net/movies/avengersendgamenew-dub-1080p.mp4', '', '<p>Ap&oacute;s os eventos devastadores de &quot;Vingadores: Guerra Infinita&quot;, o universo est&aacute; em ru&iacute;nas devido aos esfor&ccedil;os do Tit&atilde; Louco, Thanos. Com a ajuda de aliados remanescentes, os Vingadores devem se reunir mais uma vez a fim de desfazer as a&ccedil;&otilde;es de Thanos e restaurar a ordem no universo de uma vez por todas, n&atilde;o importando as consequ&ecirc;ncias.</p>', 16, '0', '0', 0, 1, 1),
(25, 8, '3,7', 'server_url', 'Godzilla II: Rei dos Monstros (2019)', '53652_uovH5k4BAEPqXqxgwVrTtqH169g.jpg', '33428_z6JxhQnpxVz6rfFHbAL8MWFaiPL.jpg', 'http://mrq1.azureedge.net/movies/godzilla2019-dub-1080p.mp4', '', '<p>A nova hist&oacute;ria segue os esfor&ccedil;os her&oacute;icos da ag&ecirc;ncia de criptografia zool&oacute;gico Monarch como seus membros enfrentam uma bateria de monstros do tamanho de Deus, incluindo o poderoso Godzilla, que colide com Mothra, Rodan e seu inimigo final, o rei de tr&ecirc;s cabe&ccedil;as Ghidorah. Quando essas antigas superesp&eacute;cies - pensadas como mitos - voltam a crescer, todas disputam a supremacia, deixando a pr&oacute;pria exist&ecirc;ncia da humanidade na balan&ccedil;a.</p>', 4, '0', '0', 0, 1, 1),
(26, 12, '3', 'server_url', 'Velozes & Furiosos: Hobbs & Shaw (2019)', '83690_qAhedRxRYWZAgZ8O8pHIl6QHdD7.jpg', '66084_gfxjcTaWGGyyWSG4znWoyR9hsfe.jpg', 'http://mrq1.azureedge.net/movies/velozesfuriosos2019-dub-720p.mp4', '', '<p>Desde que se conheceram, em &quot;Velozes &amp; Furiosos 7&quot;, Luke Hobbs (Dwayne Johnson) e Deckard Shaw (Jason Statham) constantemente bateram de frente, n&atilde;o s&oacute; por inicialmente estarem em lados opostos mas, especialmente, pela personalidade de cada um. Agora, a dupla precisa unir for&ccedil;as para enfrentar Brixton (Idris Elba), um anarquista alterado geneticamente que se tornou uma amea&ccedil;a biol&oacute;gica global. Para tanto, eles contam com a ajuda de Hattie (Vanessa Kirby), irm&atilde; de Shaw, que &eacute; tamb&eacute;m agente do MI6, o servi&ccedil;o secreto brit&acirc;nico.</p>', 0, '0', '0', 0, 1, 1),
(27, 8, '3,7', 'server_url', 'Aladdin (2019)', '69789_rVqY0Bo4Npf6EIONUROxjYAJfmD.jpg', '70601_cYlzLYlhUXS0kW9T3ttAQ6fvZuV.jpg', 'http://mrq1.azureedge.net/movies/aladdin-dub-1080p.mp4', '', '<p>Um jovem humilde descobre uma l&acirc;mpada m&aacute;gica, com um g&ecirc;nio que pode lhe conceder desejos. Agora o rapaz quer conquistar a mo&ccedil;a por quem se apaixonou, mas o que ele n&atilde;o sabe &eacute; que a jovem &eacute; uma princesa que est&aacute; prestes a se noivar. Agora, com a ajuda do G&ecirc;nio (Will Smith), ele tenta se passar por um pr&iacute;ncipe e para conquistar o amor da mo&ccedil;a e a confian&ccedil;a de seu pai.</p>', 0, '0', '0', 0, 0, 1),
(28, 10, '3,7', 'server_url', 'Hellboy (2019)', '64523_5BkSkNtfrnTuKOtTaZhl8avn4wU.jpg', '19947_cDZuziwzavShfWMkBIPgNVMfDK7 (1).jpg', 'http://mrq1.azureedge.net/movies/hellboy-dub-1080p.mp4', '', '<p>Ao chegar &agrave; Terra ainda crian&ccedil;a, ap&oacute;s ser invocado por um feiticeiro contratado pelo governo nazista, Hellboy (David Harbour) foi criado como um filho por Trevor Bruttenholm (Ian McShane), um professor que estava no local no momento em que emergiu do inferno. J&aacute; adulto, Hellboy se torna um aliado dos humanos na batalha contra monstros de todo tipo. Quando a poderosa feiticeira Nimue (Milla Jovovich), tamb&eacute;m conhecida com a Rainha Sangrenta, insinua seu retorno, ele logo &eacute; convocado para enfrent&aacute;-la.</p>', 0, '0', '0', 0, 1, 1),
(29, 8, '3', 'server_url', 'Alita: Anjo de Combate (2019)', '64441_8RKBHHRqOMOLh5qW3sS6TSFTd8h.jpg', '96895_i7eGbUjw721W02ofWEJt4zpiJDp.jpg', 'http://mrq1.azureedge.net/movies/alitaanjocombate-dub-720p.mp4', '', '<p>Quando Alita (Rosa Salazar) desperta sem mem&oacute;ria de quem &eacute;, em um mundo futur&iacute;stico que n&atilde;o reconhece, ela &eacute; levada por Ido (Christoph Waltz), um m&eacute;dico compassivo que percebe que em algum lugar nesta casca de ciborgue abandonada est&aacute; o cora&ccedil;&atilde;o e alma de uma jovem mulher com um passado extraordin&aacute;rio. Enquanto Alita aprende a navegar sua nova vida e as ruas trai&ccedil;oeiras da Cidade de Ferro, Ido tenta proteg&ecirc;-la de sua misteriosa hist&oacute;ria, enquanto seu novo amigo de rua Hugo (Keean Johnson) oferece ajuda para recuperar suas mem&oacute;rias. Mas &eacute; somente quando as for&ccedil;as mortais e corruptas que controlam a cidade v&ecirc;m atr&aacute;s de Alita que ela descobre uma pista de seu passado, ela tem habilidades &uacute;nicas de combate que os que est&atilde;o no poder n&atilde;o conseguem controlar. Se ela puder ficar fora de seu alcance, pode ser a chave para salvar seus amigos, sua fam&iacute;lia e o mundo que ela est&aacute; amando.</p>', 0, '0', '0', 0, 0, 1),
(30, 10, '3,7,8', 'server_url', 'Capitã Marvel (2019)', '53382_nBS1vONGYrsL2C68C2oDQ3eKJR1.jpg', '31678_hVgLHgnsO46oSHJy5I4ekhqtoYv.jpg', 'http://mrq1.azureedge.net/movies/cptmarvel-dub-hdts.mp4', '', '<p>A hist&oacute;ria segue Carol Danvers e como ela se torna um dos her&oacute;is mais poderosos do universo quando a Terra &eacute; pega no meio de uma guerra gal&aacute;ctica entre duas ra&ccedil;as alien&iacute;genas. Situado na d&eacute;cada de 1990, Capit&atilde; Marvel &eacute; uma nova aventura de um per&iacute;odo in&eacute;dito na hist&oacute;ria do universo cinematogr&aacute;fico da Marvel.</p>', 0, '0', '0', 0, 0, 1),
(31, 5, '3,7', 'server_url', 'Animais Fantásticos: Os Crimes de Grindelwald (2018)', '4223_zsBJzQBPKuoMQm2VI0v1eI4OxYg.jpg', '44894_qflbWgNtthGGl8nURPfffGEgZu6.jpg', 'http://mrq1.azureedge.net/movies/animaisfantasticoscrimesgrindelwald-dub-1080p.mp4', '', '<p>Newt Scamander (Eddie Redmayne) reencontra os queridos amigos Tina Goldstein (Katherine Waterston), Queenie Goldstein (Alison Sudol) e Jacob Kowalski (Dan Fogler). Ele &eacute; recrutado pelo seu antigo professor em Hogwarts, Alvo Dumbledore (Jude Law), para enfrentar o terr&iacute;vel bruxo das trevas Gellert Grindelwald (Johnny Depp), que escapou da cust&oacute;dia da MACUSA (Congresso M&aacute;gico dos EUA) e re&uacute;ne seguidores, dividindo o mundo entre seres de magos sangue puro e seres n&atilde;o-m&aacute;gicos.</p>', 1, '0', '0', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip` text NOT NULL,
  `rate` int(11) NOT NULL,
  `type` varchar(60) NOT NULL,
  `dt_rate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reports`
--

CREATE TABLE `tbl_reports` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `report` text NOT NULL,
  `type` varchar(60) NOT NULL,
  `report_on` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_season`
--

CREATE TABLE `tbl_season` (
  `id` int(10) NOT NULL,
  `series_id` int(10) NOT NULL,
  `season_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_season`
--

INSERT INTO `tbl_season` (`id`, `series_id`, `season_name`, `status`) VALUES
(1, 1, 'Temporada 1°', 1),
(2, 1, 'Temporada 2°', 1),
(3, 1, 'Temporada 3°', 1),
(4, 3, '1° Temporada', 1),
(5, 4, '1° Temporada', 1),
(6, 4, '2° Temporada', 1),
(7, 4, '3° Temporada', 1),
(8, 5, '1° Temporada', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_series`
--

CREATE TABLE `tbl_series` (
  `id` int(10) NOT NULL,
  `series_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `series_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `series_poster` text COLLATE utf8_unicode_ci NOT NULL,
  `series_cover` text COLLATE utf8_unicode_ci NOT NULL,
  `total_views` int(11) NOT NULL DEFAULT 0,
  `total_rate` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `rate_avg` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `is_featured` int(1) NOT NULL DEFAULT 0,
  `is_slider` int(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_series`
--

INSERT INTO `tbl_series` (`id`, `series_name`, `series_desc`, `series_poster`, `series_cover`, `total_views`, `total_rate`, `rate_avg`, `is_featured`, `is_slider`, `status`) VALUES
(1, 'Game Of Thrones', '<p><em><strong>Game of Thrones</strong></em>&nbsp;is an American&nbsp;fantasy&nbsp;drama&nbsp;television series created by&nbsp;David Benioff&nbsp;and&nbsp;D. B. Weiss&nbsp;for&nbsp;HBO. It is an adaptation of&nbsp;<em>A Song of Ice and Fire</em>,&nbsp;George R. R. Martin&#39;s series of fantasy novels, the first of which is&nbsp;<em>A Game of Thrones</em>. The show was both produced and filmed in&nbsp;Belfast&nbsp;and elsewhere in the&nbsp;United Kingdom. Filming locations also included Canada, Croatia, Iceland, Malta, Morocco, and Spain. The series premiered on&nbsp;HBO&nbsp;in the United States on April 17, 2011, and concluded on May 19, 2019, with 73 episodes broadcast over eight seasons.</p>', '36869_got.jpg', '48629_d0bd7hlw0aagvyc-cropped.jpg', 212, '0', '0', 0, 0, 1),
(2, 'Arrow', '<p><em><strong>Arrow</strong></em>&nbsp;is an American&nbsp;superhero&nbsp;television series developed by&nbsp;Greg Berlanti,&nbsp;Marc Guggenheim, and&nbsp;Andrew Kreisberg&nbsp;based on the&nbsp;DC Comics&nbsp;character&nbsp;Green Arrow, a costumed crime-fighter created by&nbsp;Mort Weisinger&nbsp;and&nbsp;George Papp, and is set in the&nbsp;Arrowverse, sharing continuity with other Arrowverse television series. The series premiered in the United States on&nbsp;The CW&nbsp;on October 10, 2012, with international broadcasting taking place in late 2012 and primarily filmed in&nbsp;Vancouver,&nbsp;British Columbia, Canada.&nbsp;<em>Arrow</em>&nbsp;follows billionaire playboy&nbsp;Oliver Queen&nbsp;(Stephen Amell), who claimed to have spent five years shipwrecked on&nbsp;Lian Yu, a mysterious island in the North China Sea, before returning home to&nbsp;Starling City&nbsp;(later renamed &quot;Star City&quot;) to fight crime and corruption as a secret vigilante whose weapon of choice is a bow and arrow.</p>\r\n\r\n<p>Music</p>', '1374_arrow1.jpg', '78883_arrow.jpg', 104, '1', '4', 0, 1, 1),
(3, 'The Boys (2019)', '<p>Na trama, conhecemos um mundo em que super-her&oacute;is s&atilde;o as maiores celebridades do planeta, e rotineiramente abusam dos seus poderes ao inv&eacute;s de os usarem para o bem.</p>', '64595_dzOxNbbz1liFzHU1IPvdgUR647b.jpg', '48331_bI37vIHSH7o4IVkq37P8cfxQGMx.jpg', 1, '0', '0', 0, 0, 1),
(4, 'La casa de papel (2017)', '<p>Um homem misterioso que atende pelo nome de El Profesor, est&aacute; planejando o maior assalto do s&eacute;culo. A fim de realizar o ambicioso plano ele recruta uma gangue de oito pessoas com certas habilidades que n&atilde;o tem nada a perder. O objetivo &eacute; infiltrar na Casa da Moeda, de modo que eles possam imprimir 2,4 bilh&otilde;es de euros. Para fazer isso eles precisam de onze dias de reclus&atilde;o, durante o qual eles v&atilde;o ter que lidar com sessenta e sete ref&eacute;ns e as for&ccedil;as da Pol&iacute;cia de Elite, com cenas de muita a&ccedil;&atilde;o e planos brilhantes de El Profesor.</p>', '48487_dQtiDcc8N1joORj3E6oWC8vZVCb.jpg', '20384_m8Lp1ChUMIlZS4oOQ494Kp4iV2b.jpg', 0, '0', '0', 0, 0, 1),
(5, 'Saint Seya: Os Cavaleiros do Zodíaco (2019)', '<p>Seiya e Os Cavaleiros do Zod&iacute;aco est&atilde;o de volta para proteger a reencarna&ccedil;&atilde;o da deusa Atena, mas uma obscura profecia paira sobre todos eles.</p>', '97837_j39p6zfHETY2O8nakbOHcwcMxay.jpg', '37203_9c3MBr4wbfRoBvx5qjJRKocifB5.jpg', 1, '0', '0', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--

CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `envato_buyer_name` varchar(255) NOT NULL,
  `envato_purchase_code` varchar(255) NOT NULL,
  `envato_buyer_email` varchar(150) NOT NULL,
  `envato_purchased_status` int(1) NOT NULL DEFAULT 0,
  `package_name` varchar(255) NOT NULL,
  `ios_bundle_identifier` varchar(255) NOT NULL,
  `email_from` varchar(255) NOT NULL,
  `onesignal_app_id` varchar(500) NOT NULL,
  `onesignal_rest_key` varchar(500) NOT NULL,
  `app_name` varchar(255) NOT NULL,
  `app_logo` varchar(255) NOT NULL,
  `app_email` varchar(255) NOT NULL,
  `app_version` varchar(255) NOT NULL,
  `app_author` varchar(255) NOT NULL,
  `app_contact` varchar(255) NOT NULL,
  `app_website` varchar(255) NOT NULL,
  `app_description` text NOT NULL,
  `app_developed_by` varchar(255) NOT NULL,
  `app_privacy_policy` text NOT NULL,
  `api_latest_limit` int(3) NOT NULL,
  `api_page_limit` int(5) NOT NULL,
  `api_cat_order_by` varchar(255) NOT NULL,
  `api_cat_post_order_by` varchar(255) NOT NULL,
  `api_lan_order_by` varchar(20) NOT NULL,
  `api_gen_order_by` varchar(20) NOT NULL,
  `publisher_id` varchar(500) NOT NULL,
  `interstital_ad` varchar(500) NOT NULL,
  `interstital_ad_id` varchar(500) NOT NULL,
  `interstital_ad_click` varchar(500) NOT NULL,
  `banner_ad` varchar(500) NOT NULL,
  `banner_ad_id` varchar(500) NOT NULL,
  `publisher_id_ios` varchar(500) NOT NULL,
  `app_id_ios` varchar(500) NOT NULL,
  `interstital_ad_ios` varchar(500) NOT NULL,
  `interstital_ad_id_ios` varchar(500) NOT NULL,
  `interstital_ad_click_ios` varchar(500) NOT NULL,
  `banner_ad_ios` varchar(500) NOT NULL,
  `banner_ad_id_ios` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `envato_buyer_name`, `envato_purchase_code`, `envato_buyer_email`, `envato_purchased_status`, `package_name`, `ios_bundle_identifier`, `email_from`, `onesignal_app_id`, `onesignal_rest_key`, `app_name`, `app_logo`, `app_email`, `app_version`, `app_author`, `app_contact`, `app_website`, `app_description`, `app_developed_by`, `app_privacy_policy`, `api_latest_limit`, `api_page_limit`, `api_cat_order_by`, `api_cat_post_order_by`, `api_lan_order_by`, `api_gen_order_by`, `publisher_id`, `interstital_ad`, `interstital_ad_id`, `interstital_ad_click`, `banner_ad`, `banner_ad_id`, `publisher_id_ios`, `app_id_ios`, `interstital_ad_ios`, `interstital_ad_id_ios`, `interstital_ad_click_ios`, `banner_ad_ios`, `banner_ad_id_ios`) VALUES
(1, 'sueliiox3', '952f9ff1-b53b-449b-ba65-48f09d50d476', '', 1, 'com.tk.darkcine', 'com.appdemo.darkcine', 'Admin@gmail.com', '3ff3b05d-d419-451b-bc06-146c02fc4f07', 'ZTIyZDVmZWYtYzdjZC00MThiLWEwMjktN2Y2NWZhNjUyOWRj', 'DarkCine 1.0', 'web_hi_res_512.png', 'admin@gmail.com', '1.0.0', 'DarkCine 1.0', '', 'www.meusite.com', '<p>Assista seus canais de TV favoritos Ao vivo em seu celular com este aplicativo no seu dispositivo. que suportam quase todo o formato. O aplicativo &eacute; especialmente otimizado para ser extremamente f&aacute;cil de configurar e documenta&ccedil;&atilde;o detalhada &eacute; fornecida.</p>\r\n', 'darkcine', '<p><strong><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Temos o compromisso de proteger sua privacidade</font></font></strong></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Coletamos a quantidade m&iacute;nima de informa&ccedil;&otilde;es sobre voc&ecirc; que &eacute; proporcional ao fornecimento de um servi&ccedil;o satisfat&oacute;rio. </font><font style=\"vertical-align: inherit;\">Esta pol&iacute;tica indica o tipo de processos que podem resultar em dados coletados sobre voc&ecirc;. </font><font style=\"vertical-align: inherit;\">Seu uso deste site nos d&aacute; o direito de coletar essas informa&ccedil;&otilde;es.&nbsp;</font></font></p>\r\n\r\n<p><strong><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Informa&ccedil;&otilde;es coletadas</font></font></strong></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Podemos coletar qualquer ou todas as informa&ccedil;&otilde;es que voc&ecirc; nos fornecer, dependendo do tipo de transa&ccedil;&atilde;o que voc&ecirc; fizer, incluindo seu nome, endere&ccedil;o, n&uacute;mero de telefone e endere&ccedil;o de e-mail, juntamente com os dados sobre o seu uso do site. </font><font style=\"vertical-align: inherit;\">Outras informa&ccedil;&otilde;es que podem ser necess&aacute;rias de tempos em tempos para processar uma solicita&ccedil;&atilde;o tamb&eacute;m podem ser coletadas conforme indicado no site.</font></font></p>\r\n\r\n<p><strong><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Uso de Informa&ccedil;&atilde;o</font></font></strong></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Usamos as informa&ccedil;&otilde;es coletadas principalmente para processar a tarefa para a qual voc&ecirc; visitou o site. </font><font style=\"vertical-align: inherit;\">Os dados coletados no Reino Unido s&atilde;o realizados de acordo com a Lei de Prote&ccedil;&atilde;o de Dados. </font><font style=\"vertical-align: inherit;\">Todas as precau&ccedil;&otilde;es razo&aacute;veis ​​s&atilde;o tomadas para impedir o acesso n&atilde;o autorizado a essas informa&ccedil;&otilde;es. </font><font style=\"vertical-align: inherit;\">Esta salvaguarda pode exigir que voc&ecirc; forne&ccedil;a formas adicionais de identidade, caso deseje obter informa&ccedil;&otilde;es sobre os detalhes da sua conta.</font></font></p>\r\n\r\n<p><strong><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Biscoitos</font></font></strong></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Seu navegador de Internet tem o recurso integrado para armazenar arquivos pequenos - &quot;cookies&quot; - que cont&ecirc;m informa&ccedil;&otilde;es que permitem que um site reconhe&ccedil;a sua conta. </font><font style=\"vertical-align: inherit;\">Nosso site aproveita essa facilidade para aprimorar sua experi&ecirc;ncia. </font><font style=\"vertical-align: inherit;\">Voc&ecirc; tem a capacidade de impedir que o seu computador aceite cookies, mas, se o fizer, certas funcionalidades do site poder&atilde;o ser prejudicadas.</font></font></p>\r\n\r\n<p><strong><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Divulgando Informa&ccedil;&otilde;es</font></font></strong></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">N&oacute;s n&atilde;o divulgamos quaisquer informa&ccedil;&otilde;es pessoais obtidas sobre voc&ecirc; deste site para terceiros, a menos que voc&ecirc; nos permita, marcando as caixas relevantes nos formul&aacute;rios de inscri&ccedil;&atilde;o ou competi&ccedil;&atilde;o. </font><font style=\"vertical-align: inherit;\">Tamb&eacute;m podemos usar as informa&ccedil;&otilde;es para manter contato com voc&ecirc; e inform&aacute;-lo sobre os desenvolvimentos associados a n&oacute;s. </font><font style=\"vertical-align: inherit;\">Voc&ecirc; ter&aacute; a oportunidade de se retirar de qualquer lista de discuss&atilde;o ou dispositivo similar. </font><font style=\"vertical-align: inherit;\">Se, a qualquer momento no futuro, desejarmos divulgar as informa&ccedil;&otilde;es coletadas neste site a terceiros, elas ser&atilde;o apenas com seu conhecimento e consentimento.&nbsp;</font></font></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Podemos, de tempos em tempos, fornecer informa&ccedil;&otilde;es de car&aacute;ter geral a terceiros - por exemplo, o n&uacute;mero de pessoas que visitam nosso site ou preencher um formul&aacute;rio de registro, mas n&atilde;o usaremos nenhuma informa&ccedil;&atilde;o que possa identificar esses indiv&iacute;duos.&nbsp;</font></font></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Al&eacute;m disso, a Dummy pode trabalhar com terceiros com o objetivo de fornecer publicidade comportamental direcionada ao site da Dummy. </font><font style=\"vertical-align: inherit;\">Atrav&eacute;s do uso de cookies, informa&ccedil;&otilde;es an&ocirc;nimas sobre o uso de nossos sites e outros sites ser&atilde;o usadas para fornecer an&uacute;ncios mais relevantes sobre bens e servi&ccedil;os de interesse para voc&ecirc;. </font><font style=\"vertical-align: inherit;\">Para obter mais informa&ccedil;&otilde;es sobre publicidade comportamental on-line e sobre como desativar esse recurso, visite youronlinechoices.com/opt-out.</font></font></p>\r\n\r\n<p><strong><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Altera&ccedil;&otilde;es a esta pol&iacute;tica</font></font></strong></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Quaisquer altera&ccedil;&otilde;es &agrave; nossa Pol&iacute;tica de Privacidade ser&atilde;o colocadas aqui e substituir&atilde;o esta vers&atilde;o da nossa pol&iacute;tica. </font><font style=\"vertical-align: inherit;\">Tomaremos medidas razo&aacute;veis ​​para chamar sua aten&ccedil;&atilde;o para quaisquer altera&ccedil;&otilde;es em nossa pol&iacute;tica. </font><font style=\"vertical-align: inherit;\">No entanto, para estar no lado seguro, sugerimos que voc&ecirc; leia este documento toda vez que usar o site para garantir que ele ainda esteja de acordo com sua aprova&ccedil;&atilde;o.</font></font></p>\r\n\r\n<p><strong><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Contatando-nos</font></font></strong></p>\r\n\r\n<p><font style=\"vertical-align: inherit;\"><font style=\"vertical-align: inherit;\">Se voc&ecirc; tiver alguma d&uacute;vida sobre nossa Pol&iacute;tica de Privacidade ou se quiser saber quais informa&ccedil;&otilde;es coletamos sobre voc&ecirc;, envie um e-mail para hd@dummy.com. </font><font style=\"vertical-align: inherit;\">Voc&ecirc; tamb&eacute;m pode corrigir quaisquer erros factuais nessa informa&ccedil;&atilde;o ou exigir que removamos seus dados de qualquer lista sob nosso controle.</font></font></p>\r\n', 15, 10, 'category_name', 'channel_title', 'language_name', 'genre_name', 'pub-5590674737715144', 'true', 'ca-app-pub-5590674737715144/2860272954', '1', 'true', 'ca-app-pub-5590674737715144/4874587421', 'pub-5590674737715144', 'ca-app-pub-5590674737715144~7693511820', 'true', 'ca-app-pub-5590674737715144/2860272954', '5', 'true', 'ca-app-pub-5590674737715144/4874587421');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `confirm_code` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_type`, `name`, `email`, `password`, `phone`, `confirm_code`, `status`) VALUES
(1, 'Normal', 'Darkcine', 'player-xs@outlook.com', '017305', '976558484854', NULL, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_channels`
--
ALTER TABLE `tbl_channels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_episode`
--
ALTER TABLE `tbl_episode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_genres`
--
ALTER TABLE `tbl_genres`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `tbl_home`
--
ALTER TABLE `tbl_home`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_language`
--
ALTER TABLE `tbl_language`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_movies`
--
ALTER TABLE `tbl_movies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_season`
--
ALTER TABLE `tbl_season`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_series`
--
ALTER TABLE `tbl_series`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_channels`
--
ALTER TABLE `tbl_channels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_episode`
--
ALTER TABLE `tbl_episode`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_genres`
--
ALTER TABLE `tbl_genres`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_home`
--
ALTER TABLE `tbl_home`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_language`
--
ALTER TABLE `tbl_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_movies`
--
ALTER TABLE `tbl_movies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_season`
--
ALTER TABLE `tbl_season`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_series`
--
ALTER TABLE `tbl_series`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
